package com.uacm.pixelpalace.service;


import com.uacm.pixelpalace.model.DetalleVenta;


public interface IDetalleVentaService {
	DetalleVenta save (DetalleVenta detalleVenta);
}
