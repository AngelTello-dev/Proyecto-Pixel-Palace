package com.uacm.pixelpalace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PixelPalaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
