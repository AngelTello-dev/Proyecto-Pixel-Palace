package com.uacm.pixelpalace.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.uacm.pixelpalace.model.Requisito;

@Repository
public interface IRequisitoRepository extends JpaRepository<Requisito, Integer>{

}
