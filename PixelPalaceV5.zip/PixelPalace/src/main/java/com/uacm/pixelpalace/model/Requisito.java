package com.uacm.pixelpalace.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "requisitos")
public class Requisito {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String sitemaOperativo;
	private String procesador;
	private String ram;
	private String tarjeta_grafica;
	private String almacenamiento;

	public Requisito() {

	}

	public Requisito(Integer id, String sitemaOperativo, String procesador, String ram, String tarjeta_grafica,
			String almacenamiento) {
		this.id = id;
		this.sitemaOperativo = sitemaOperativo;
		this.procesador = procesador;
		this.ram = ram;
		this.tarjeta_grafica = tarjeta_grafica;
		this.almacenamiento = almacenamiento;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSitemaOperativo() {
		return sitemaOperativo;
	}

	public void setSitemaOperativo(String sitemaOperativo) {
		this.sitemaOperativo = sitemaOperativo;
	}

	public String getProcesador() {
		return procesador;
	}

	public void setProcesador(String procesador) {
		this.procesador = procesador;
	}

	public String getRam() {
		return ram;
	}

	public void setRam(String ram) {
		this.ram = ram;
	}

	public String getTarjeta_grafica() {
		return tarjeta_grafica;
	}

	public void setTarjeta_grafica(String tarjeta_grafica) {
		this.tarjeta_grafica = tarjeta_grafica;
	}

	public String getAlmacenamiento() {
		return almacenamiento;
	}

	public void setAlmacenamiento(String almacenamiento) {
		this.almacenamiento = almacenamiento;
	}

	@Override
	public String toString() {
		return "Requisito [id=" + id + ", sitemaOperativo=" + sitemaOperativo + ", procesador=" + procesador + ", ram="
				+ ram + ", tarjeta_grafica=" + tarjeta_grafica + ", almacenamiento=" + almacenamiento + "]";
	}



}
