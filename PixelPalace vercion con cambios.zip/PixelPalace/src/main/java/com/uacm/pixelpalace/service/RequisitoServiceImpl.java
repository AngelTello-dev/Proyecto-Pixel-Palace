package com.uacm.pixelpalace.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uacm.pixelpalace.model.Requisito;
import com.uacm.pixelpalace.repository.IRequisitoRepository;


@Service
public class RequisitoServiceImpl implements IRequisitoService{

	@Autowired
	private IRequisitoRepository requisitoRepository;

	@Override
	public Requisito save(Requisito requisito) {
		return requisitoRepository.save(requisito);
	}

	@Override
	public Optional<Requisito> get(Integer id) {
		return requisitoRepository.findById(id);
	}

	@Override
	public void update(Requisito requisito) {
		requisitoRepository.save(requisito);
	}

	@Override
	public void delete(Integer id) {
		requisitoRepository.deleteById(id);

	}

	@Override
	public List<Requisito> findAll() {
		return requisitoRepository.findAll();
	}

	@Override
	public Optional<Requisito> findById(Integer id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

}
