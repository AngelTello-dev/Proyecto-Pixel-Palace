package com.uacm.pixelpalace.service;

import java.util.List;
import java.util.Optional;

import com.uacm.pixelpalace.model.Requisito;


public interface IRequisitoService {
	public Requisito save(Requisito requisito);
	public Optional<Requisito> get(Integer id);
	Optional<Requisito> findById(Integer id);
	public void update(Requisito requisito);
	public void delete(Integer id);
	public List<Requisito> findAll();
}
